import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { DarSchema, SubmissionResponse } from "./dar.models";

@Injectable({ 
    providedIn: "root" 
})

export class DarApiService {
    constructor(private http: HttpClient) {}
    schema(slug: string): Observable<DarSchema> {
        return this.http.get<DarSchema>(`http://localhost:4200/api/dar/forms`, {
        withCredentials: true,
        });
    }

    submit(form_slug: string, data: any, status: "draft" | "submitted" = "submitted"): Observable<SubmissionResponse> {
        return this.http.post<SubmissionResponse>("/api/angular/submissions/", { form_slug, status, context: {}, data },
        { 
            withCredentials: true, headers: new HttpHeaders({ "X-CSRFToken": this.cookie("csrftoken") }),
        });
    
    }
        private cookie(name: string): string {const row = document.cookie.split("; ").find((x) => x.startsWith(name + "="));
        return row ? decodeURIComponent(row.split("=")[1]) : "";
    }
}
