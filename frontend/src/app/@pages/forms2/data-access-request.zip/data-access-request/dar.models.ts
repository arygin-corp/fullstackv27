/*
 * Data Access Request models
 *
 * This file supports:
 * 1. Schema-driven DAR fields and validation
 * 2. Conditional field display through show_when
 * 3. Grouped rules with separate actions
 * 4. Legacy field-level rules containing action information
 * 5. Runtime field-state evaluation
 */

/* ==========================================================================
 * Common types
 * ========================================================================== */

export type FieldType =
  | 'text'
  | 'textarea'
  | 'email'
  | 'integer'
  | 'decimal'
  | 'date'
  | 'datetime'
  | 'checkbox'
  | 'select'
  | 'multiselect'
  | 'radio'
  | 'user_lookup'
  | 'hidden'
  | 'static_text';

export type DarValue =
  | string
  | number
  | boolean
  | null
  | string[]
  | number[]
  | Record<string, unknown>
  | unknown[];

/* ==========================================================================
 * Field options and validation
 * ========================================================================== */

export interface Option {
  id: number;
  label: string;
  value: string;
  order: number;
  metadata: any;
}

export interface ValidationValue {
  length?: number;
  pattern?: string;
  min?: number;
  max?: number;
  [key: string]: unknown;
}

export interface Validation {
  id: number;
  validation_type: string;
  validation_value: ValidationValue | any;
  error_message: string;
  order: number;
  is_active: boolean;
}

/* ==========================================================================
 * Rule operators and action types
 * ========================================================================== */

export enum RuleOperator {
  EQUALS = 'equals',
  NOT_EQUALS = 'not_equals',
  IN = 'in',
  NOT_IN = 'not_in',
  IS_EMPTY = 'is_empty',
  IS_NOT_EMPTY = 'is_not_empty',
  CONTAINS = 'contains',
  TRUTHY = 'truthy',
  FALSY = 'falsy',
  GT = 'gt',
  GTE = 'gte',
  LT = 'lt',
  LTE = 'lte',
  REGEX = 'regex'
}

export enum RuleActionType {
  SHOW = 'show',
  HIDE = 'hide',
  ENABLE = 'enable',
  DISABLE = 'disable',
  REQUIRE = 'require',
  OPTIONAL = 'optional',
  SET_VALUE = 'set_value',
  CLEAR_VALUE = 'clear_value'
}

/* ==========================================================================
 * Simple field condition
 *
 * Used by DarField.show_when.
 * ========================================================================== */

export interface DarCondition {
  field: string;
  operator?: RuleOperator | string;
  value?: unknown;
  values?: unknown[];
}

/* ==========================================================================
 * Grouped-rule action
 *
 * Grouped actions use action_type.
 * Legacy field rules use action.
 *
 * Keeping these shapes distinct allows TypeScript to narrow:
 * DarRule | DarAction
 * using the "action_type" property.
 * ========================================================================== */

export interface DarAction {
  id?: number;

  action_type: RuleActionType;
  target_key: string;
  action_value?: unknown;

  order?: number;
  is_active?: boolean;
}

/* ==========================================================================
 * Rule condition and legacy field-level action
 *
 * The rule condition is evaluated using:
 * - source_key
 * - operator
 * - comparison_value
 *
 * A legacy field-level rule may also contain:
 * - target_key
 * - action
 * - action_value
 * ========================================================================== */

export interface DarRule {
  id?: number;
  is_active?: boolean;

  /**
   * Group identifier.
   *
   * null or undefined indicates that the rule is a legacy,
   * ungrouped field-level rule.
   */
  group?: number | null;

  /**
   * Required because the component sorts directly with:
   * left.order - right.order
   */
  order: number;

  source_key: string;
  operator: RuleOperator;
  comparison_value?: unknown;

  /**
   * Legacy action fields.
   */
  target_key?: string;
  action?: RuleActionType;
  action_value?: unknown;
}

/* ==========================================================================
 * Rule groups
 * ========================================================================== */

export interface DarRuleGroup {
  id?: number;
  name?: string;
  is_active?: boolean;

  /**
   * Required because the component sorts directly with:
   * left.priority - right.priority
   */
  priority: number;

  /**
   * "all" means every rule must match.
   * "any" means at least one rule must match.
   */
  evaluation_mode: 'all' | 'any';

  rules: DarRule[];

  /**
   * Optional because the component uses:
   * group.actions || []
   */
  actions?: DarAction[];
}

/* ==========================================================================
 * DAR fields
 * ========================================================================== */

export interface DarField {
  id: number;
  key: string;
  label: string;
  field_type: FieldType;

  help_text: string;
  placeholder: string;
  error_message: string;

  order: number;

  required: boolean;
  disabled: boolean;
  read_only: boolean;
  hidden: boolean;

  default_value: any;

  max_selected_items: number | null;
  external_source: string;
  metadata: any;

  options: Option[];
  validations: Validation[];

  /**
   * Direct validation properties used by the component.
   */
  min_length?: number;
  max_length?: number;
  regex_pattern?: string;

  /**
   * Simple field visibility condition.
   */
  show_when?: DarCondition;

  /**
   * Legacy field-level rules.
   */
  rules?: DarRule[];
}

/* ==========================================================================
 * Schema sections
 * ========================================================================== */

export interface Section {
  id: number;
  title: string;
  description: string;
  order: number;
  section_fields: DarField[];
}

/* ==========================================================================
 * Complete DAR schema
 * ========================================================================== */

export interface DarSchema {
  id: number;
  name: string;
  slug: string;
  description: string;

  version: number;
  schema_version: string;

  success_title: string;
  success_message: string;

  sections: Section[];
  unsectioned_fields: DarField[];

  /**
   * New grouped rules-engine configuration.
   */
  rule_groups?: DarRuleGroup[];
}

/* ==========================================================================
 * Runtime field state
 *
 * Uses the exact property names expected by the component.
 * ========================================================================== */

export interface RuntimeFieldState {
  hidden: boolean;
  disabled: boolean;
  required: boolean;
  readOnly: boolean;
  value: unknown;
}

/* ==========================================================================
 * Submission response
 * ========================================================================== */

export interface SubmissionResponse {
  id: number;
  status: string;
  request_number: string | null;
  context: any;
  values: any[];
}