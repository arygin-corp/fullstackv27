import {
  Component,
  Input,
  OnDestroy,
  OnInit
} from '@angular/core';

import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidatorFn,
  Validators
} from '@angular/forms';

import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { DarApiService } from './dar-api.service';

import {
  DarAction,
  DarField,
  DarRule,
  DarRuleGroup,
  DarSchema,
  RuleActionType,
  RuleOperator,
  RuntimeFieldState
} from './dar.models';

interface RequiredFieldItem {
  label: string;
  control: string;
  valid: boolean;
}

interface RequiredFieldDefinition {
  label: string;
  control: string;
  controls?: string[];
  visible?: () => boolean;
  valid?: () => boolean;
}

@Component({
  selector: 'app-data-access-request',
  templateUrl: './data-access-request.component.html',
  styleUrls: ['./data-access-request.component.scss']
})
export class DataAccessRequestComponent
  implements OnInit, OnDestroy {

  @Input()
  formSlug = 'data-access-request';

  schema?: DarSchema;

  form: FormGroup = this.fb.group({});

  loading = true;
  submitting = false;

  success?: string;
  fatal?: string;

  serverErrors: Record<string, string | string[]> = {};

  /*
   * Runtime state is separate from the immutable schema.
   * The schema contains the baseline state. Matching rules transform
   * the runtime state.
   */
  runtimeState: Record<string, RuntimeFieldState> = {};

  private readonly destroy$ = new Subject<void>();

  private updatingConditionalControls = false;

  /*
   * Prevent malformed cyclic SET_VALUE/CLEAR_VALUE configurations from
   * causing an infinite loop in the browser.
   */
  private readonly maximumRulePasses = 100;

  constructor(
    private readonly fb: FormBuilder,
    private readonly api: DarApiService
  ) {}

  ngOnInit(): void {
    this.loadSchema();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadSchema(): void {
    this.loading = true;
    this.fatal = undefined;
    this.success = undefined;
    this.serverErrors = {};

    this.api
      .schema(this.formSlug)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: schema => {
          this.schema = schema;

          this.buildForm(schema);

          this.loading = false;
        },

        error: error => {
          this.loading = false;

          this.fatal =
            error?.error?.detail ||
            error?.error?.configuration ||
            'Unable to load the DAR form.';
        }
      });
  }

  /*
   * Return all form fields in schema order.
   */
  fields(
    schema: DarSchema | undefined = this.schema
  ): DarField[] {
    if (!schema) {
      return [];
    }

    const sectionFields = (schema.sections || [])
      .reduce(
        (result: DarField[], section) => [
          ...result,
          ...(section.section_fields || [])
        ],
        []
      );

    return [
      ...sectionFields,
      ...(schema.unsectioned_fields || [])
    ];
  }

  private fieldByKey(
    key: string
  ): DarField | undefined {
    return this.fields().find(field => field.key === key);
  }

  private buildForm(
    schema: DarSchema
  ): void {
    const controls: Record<string, FormControl> = {};

    for (const field of this.fields(schema)) {
      if (field.field_type === 'static_text') {
        continue;
      }

      controls[field.key] = new FormControl(
        {
          value: this.initialValue(field),
          disabled: !!field.disabled || !!field.read_only
        },
        this.validatorsForField(field, !!field.required)
      );
    }

    this.form = this.fb.group(controls);

    /*
     * Resolve conditions immediately so default values and edit values
     * produce the correct initial UI.
     */
    this.updateConditionalControls();

    this.form.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        /*
         * User edits make prior field-level server errors stale.
         */
        this.serverErrors = {};

        this.updateConditionalControls();
      });
  }

  private initialValue(
    field: DarField
  ): unknown {
    if (
      field.default_value !== null &&
      field.default_value !== undefined
    ) {
      return field.default_value;
    }

    switch (field.field_type) {
      case 'checkbox':
        return false;

      case 'multiselect':
        return [];

      default:
        return null;
    }
  }

  /*
   * Build Angular validators from both FormField settings and configured
   * ValidationRule rows.
   *
   * runtimeRequired is supplied separately because REQUIRE and OPTIONAL
   * actions can change required state without mutating the schema.
   */
  private validatorsForField(
    field: DarField,
    runtimeRequired: boolean
  ): ValidatorFn[] {
    const validators: ValidatorFn[] = [];

    if (runtimeRequired) {
      validators.push(
        field.field_type === 'checkbox'
          ? Validators.requiredTrue
          : Validators.required
      );
    }

    if (field.field_type === 'email') {
      validators.push(Validators.email);
    }

    if (field.min_length != null) {
      validators.push(
        Validators.minLength(Number(field.min_length))
      );
    }

    if (field.max_length != null) {
      validators.push(
        Validators.maxLength(Number(field.max_length))
      );
    }

    if (field.regex_pattern) {
      validators.push(
        Validators.pattern(field.regex_pattern)
      );
    }

    for (const rule of field.validations || []) {
      if (rule.is_active === false) {
        continue;
      }

      const configuration =
        rule.validation_value || {};

      switch (rule.validation_type) {
        case 'required':
          /*
           * A configured required validator is still conditional on
           * runtime visibility/enabled state because hidden or disabled
           * controls are disabled below.
           */
          validators.push(
            field.field_type === 'checkbox'
              ? Validators.requiredTrue
              : Validators.required
          );
          break;

        case 'min_length': {
          const length = configuration['length'];

          if (length !== null && length !== undefined) {
            validators.push(
              Validators.minLength(Number(length))
            );
          }

          break;
        }

        case 'max_length': {
          const length = configuration['length'];

          if (length !== null && length !== undefined) {
            validators.push(
              Validators.maxLength(Number(length))
            );
          }

          break;
        }

        case 'regex': {
          const pattern = configuration['pattern'];

          if (typeof pattern === 'string' && pattern.length > 0) {
            validators.push(
              Validators.pattern(pattern)
            );
          }

          break;
        }

        case 'email':
          validators.push(Validators.email);
          break;

        /*
         * UNIQUE, MUST_MATCH_FIELD, and CUSTOM remain server-authoritative
         * unless matching client-side implementations are added.
         */
        default:
          break;
      }
    }

    return validators;
  }

  /*
   * Resolve all field states from the current Angular control values.
   *
   * This follows the same high-level process as Django:
   *  1. Begin with FormField baseline state.
   *  2. Evaluate grouped rules.
   *  3. Apply matching grouped actions.
   *  4. Evaluate legacy ungrouped rules.
   *  5. Repeat until stable.
   */
  private resolveRuntimeStates():
    Record<string, RuntimeFieldState> {

    const fields = this.fields();

    const effectiveValues: Record<string, unknown> = {};

    for (const field of fields) {
      const control = this.form.get(field.key);

      effectiveValues[field.key] =
        control
          ? control.value
          : this.initialValue(field);
    }

    let previousSignature = '';

    let finalStates =
      this.createBaselineStates(effectiveValues);

    const maximumPasses = Math.max(
      10,
      Math.min(
        this.maximumRulePasses,
        fields.length * 2
      )
    );

    for (
      let pass = 0;
      pass < maximumPasses;
      pass += 1
    ) {
      const states =
        this.createBaselineStates(effectiveValues);

      const matchedActions =
        this.matchedActions(effectiveValues);

      for (const action of matchedActions) {
        this.applyAction(states, action);
      }

      const signature =
        this.stateSignature(states);

      finalStates = states;

      if (signature === previousSignature) {
        return finalStates;
      }

      previousSignature = signature;

      /*
       * SET_VALUE and CLEAR_VALUE can affect another condition during
       * the next pass.
       */
      for (const field of fields) {
        effectiveValues[field.key] =
          states[field.key]?.value;
      }
    }

    /*
     * Match backend safety behavior without crashing change detection.
     */
    this.fatal =
      'Form rules did not converge. Check for cyclic value rules or conflicting actions.';

    return finalStates;
  }

  private createBaselineStates(
    values: Record<string, unknown>
  ): Record<string, RuntimeFieldState> {
    const states:
      Record<string, RuntimeFieldState> = {};

    for (const field of this.fields()) {
      states[field.key] = {
        hidden: !!field.hidden,
        disabled: !!field.disabled,
        required: !!field.required,
        readOnly: !!field.read_only,

        value:
          values[field.key] !== undefined
            ? values[field.key]
            : this.initialValue(field)
      };
    }

    return states;
  }

  private matchedActions(
    values: Record<string, unknown>
  ): Array<DarAction | DarRule> {
    if (!this.schema) {
      return [];
    }

    const result: Array<DarAction | DarRule> = [];

    const groups = [...(this.schema.rule_groups || [])]
      .filter(group => group.is_active !== false)
      .sort(
        (left, right) =>
          left.priority - right.priority ||
          left.id - right.id
      );

    for (const group of groups) {
      if (!this.groupMatches(group, values)) {
        continue;
      }

      const actions = [...(group.actions || [])]
        .filter(action => action.is_active !== false)
        .sort(
          (left, right) =>
            left.order - right.order ||
            left.id - right.id
        );

      result.push(...actions);
    }

    /*
     * Backward compatibility for ungrouped legacy FieldRule records.
     * FieldSerializer exposes these through each target field's rules.
     */
    for (const field of this.fields()) {
      const legacyRules = [...(field.rules || [])]
        .filter(rule =>
          rule.is_active !== false &&
          (
            rule.group === null ||
            rule.group === undefined
          )
        )
        .sort(
          (left, right) =>
            left.order - right.order ||
            left.id - right.id
        );

      for (const rule of legacyRules) {
        if (this.ruleMatches(rule, values)) {
          result.push(rule);
        }
      }
    }

    return result;
  }

  private groupMatches(
    group: DarRuleGroup,
    values: Record<string, unknown>
  ): boolean {
    const rules = [...(group.rules || [])]
      .filter(rule => rule.is_active !== false)
      .sort(
        (left, right) =>
          left.order - right.order ||
          left.id - right.id
      );

    if (rules.length === 0) {
      return false;
    }

    const matches = rules.map(
      rule => this.ruleMatches(rule, values)
    );

    if (group.evaluation_mode === 'any') {
      return matches.some(Boolean);
    }

    return matches.every(Boolean);
  }

  private ruleMatches(
    rule: DarRule,
    values: Record<string, unknown>
  ): boolean {
    if (rule.is_active === false) {
      return false;
    }

    return this.evaluateCondition(
      rule.operator,
      values[rule.source_key],
      rule.comparison_value
    );
  }

  private evaluateCondition(
    operator: RuleOperator,
    value: unknown,
    comparison: unknown
  ): boolean {
    switch (operator) {
      case 'equals':
        return this.valuesEqual(value, comparison);

      case 'not_equals':
        return !this.valuesEqual(value, comparison);

      case 'in':
        return (
          Array.isArray(comparison) &&
          comparison.some(
            item => this.valuesEqual(value, item)
          )
        );

      case 'not_in':
        return (
          !Array.isArray(comparison) ||
          !comparison.some(
            item => this.valuesEqual(value, item)
          )
        );

      case 'is_empty':
        return this.isEmpty(value);

      case 'is_not_empty':
        return !this.isEmpty(value);

      case 'contains':
        if (typeof value === 'string') {
          return value.includes(String(comparison ?? ''));
        }

        if (Array.isArray(value)) {
          return value.some(
            item => this.valuesEqual(item, comparison)
          );
        }

        return false;

      case 'truthy':
        return this.isTruthy(value);

      case 'falsy':
        return !this.isTruthy(value);

      case 'gt':
        return this.compareValues(value, comparison) > 0;

      case 'gte':
        return this.compareValues(value, comparison) >= 0;

      case 'lt':
        return this.compareValues(value, comparison) < 0;

      case 'lte':
        return this.compareValues(value, comparison) <= 0;

      case 'regex':
        if (
          typeof value !== 'string' ||
          typeof comparison !== 'string'
        ) {
          return false;
        }

        try {
          return new RegExp(
            `^(?:${comparison})$`
          ).test(value);
        } catch {
          return false;
        }

      default:
        return false;
    }
  }

  private valuesEqual(
    left: unknown,
    right: unknown
  ): boolean {
    /*
     * Keep string comparisons exact. This is important because Django
     * compares option values such as "Yes" exactly.
     */
    if (
      typeof left === 'string' &&
      typeof right === 'string'
    ) {
      return left === right;
    }

    if (
      Array.isArray(left) ||
      Array.isArray(right) ||
      this.isPlainObject(left) ||
      this.isPlainObject(right)
    ) {
      try {
        return JSON.stringify(left) === JSON.stringify(right);
      } catch {
        return false;
      }
    }

    return left === right;
  }

  private isPlainObject(
    value: unknown
  ): value is Record<string, unknown> {
    return (
      value !== null &&
      typeof value === 'object' &&
      !Array.isArray(value)
    );
  }

  private isEmpty(
    value: unknown
  ): boolean {
    if (
      value === null ||
      value === undefined ||
      value === ''
    ) {
      return true;
    }

    if (Array.isArray(value)) {
      return value.length === 0;
    }

    if (this.isPlainObject(value)) {
      return Object.keys(value).length === 0;
    }

    return false;
  }

  private isTruthy(
    value: unknown
  ): boolean {
    if (this.isEmpty(value)) {
      return false;
    }

    return Boolean(value);
  }

  private compareValues(
    left: unknown,
    right: unknown
  ): number {
    if (
      typeof left === 'number' &&
      typeof right === 'number'
    ) {
      return left - right;
    }

    if (
      typeof left === 'string' &&
      typeof right === 'string'
    ) {
      return left.localeCompare(right);
    }

    return Number.NaN;
  }

  private applyAction(
    states: Record<string, RuntimeFieldState>,
    action: DarAction | DarRule
  ): void {
    const targetKey = action.target_key;

    const current = states[targetKey];

    if (!current) {
      return;
    }

    const actionType =
      this.actionType(action);

    const actionValue =
      action.action_value;

    switch (actionType) {
      case 'show':
        current.hidden = false;
        break;

      case 'hide':
        current.hidden = true;
        current.required = false;
        current.value = null;
        break;

      case 'require':
        current.required = true;
        break;

      case 'optional':
        current.required = false;
        break;

      case 'enable':
        current.disabled = false;
        break;

      case 'disable':
        current.disabled = true;
        current.value = null;
        break;

      case 'set_value':
        current.value = actionValue;
        break;

      case 'clear_value':
        current.value = null;
        break;

      default:
        break;
    }
  }

  private actionType(
    action: DarAction | DarRule
  ): RuleActionType {
    if ('action_type' in action) {
      return action.action_type;
    }

    return action.action;
  }

  private stateSignature(
    states: Record<string, RuntimeFieldState>
  ): string {
    const ordered = Object.keys(states)
      .sort()
      .map(key => ({
        key,
        hidden: states[key].hidden,
        disabled: states[key].disabled,
        required: states[key].required,
        readOnly: states[key].readOnly,
        value: states[key].value
      }));

    return JSON.stringify(ordered);
  }

  /*
   * Apply resolved runtime state to Angular controls.
   */
  private updateConditionalControls(): void {
    if (
      !this.schema ||
      this.updatingConditionalControls
    ) {
      return;
    }

    this.updatingConditionalControls = true;

    try {
      const nextStates =
        this.resolveRuntimeStates();

      for (const field of this.fields(this.schema)) {
        const state = nextStates[field.key];

        if (!state) {
          continue;
        }

        /*
         * Static text has no FormControl, but still receives runtime
         * visibility state for the template.
         */
        if (field.field_type === 'static_text') {
          continue;
        }

        const control = this.form.get(field.key);

        if (!control) {
          continue;
        }

        const shouldDisable =
          state.hidden ||
          state.disabled ||
          state.readOnly;

        /*
         * SET_VALUE, CLEAR_VALUE, HIDE, and DISABLE can change the
         * effective value. Apply changes without recursively emitting.
         */
        if (!this.valuesEqual(control.value, state.value)) {
          control.setValue(
            state.value,
            {
              emitEvent: false
            }
          );
        }

        if (shouldDisable) {
          if (control.enabled) {
            control.disable({
              emitEvent: false
            });
          }
        } else if (control.disabled) {
          control.enable({
            emitEvent: false
          });
        }

        control.setValidators(
          this.validatorsForField(
            field,
            state.required
          )
        );

        control.updateValueAndValidity({
          emitEvent: false
        });
      }

      this.runtimeState = nextStates;
    } finally {
      this.updatingConditionalControls = false;
    }
  }

  visible(
    field: DarField
  ): boolean {
    const state = this.runtimeState[field.key];

    if (state) {
      return !state.hidden;
    }

    return !field.hidden;
  }

  isRequired(
    field: DarField
  ): boolean {
    const state = this.runtimeState[field.key];

    return state
      ? state.required
      : !!field.required;
  }

  isDisabled(
    field: DarField
  ): boolean {
    const state = this.runtimeState[field.key];

    return state
      ? (
          state.hidden ||
          state.disabled ||
          state.readOnly
        )
      : (
          !!field.hidden ||
          !!field.disabled ||
          !!field.read_only
        );
  }

  /*
   * Business-facing required-information sidebar.
   *
   * The static labels remain business-friendly. Visibility and requiredness
   * are now determined from the resolved database rules.
   */
  get requiredFields(): RequiredFieldItem[] {
    if (!this.schema) {
      return [];
    }

    const definitions:
      RequiredFieldDefinition[] = [
        {
          label: 'Requested For',
          control: this.requestedForFocusControl(),
          controls: [
            'requesting_id',
            'v_dar_objectid_reqfor'
          ],
          valid: () => this.requestedForIsValid()
        },
        {
          label: 'Platform',
          control: 'v_dar_platform'
        },
        {
          label: 'Data Domain',
          control: 'v_dar_dataDomainSelect'
        },
        {
          label: 'User Access',
          control: 'v_dar_userType'
        },
        {
          label: 'Individual/App Access',
          control: 'v_dar_accessType'
        },
        {
          label: 'Request Description',
          control: 'v_dar_DataReqDescription'
        },
        {
          label: 'Intended Use',
          control: 'v_dar_businessJustification'
        },
        {
          label: 'Sensitive PI',
          control: 'v_emd_PI_access'
        },
        {
          label: 'Terms of Use',
          control: 'chk_dar_terms_message'
        },
        {
          label: 'API Name',
          control: 'v_dat_api_name'
        },
        {
          label: 'Data Warehouse/Mart',
          control: 'v_dar_select_a_data_warehouse_mart'
        },
        {
          label: 'Gateway Access',
          control: 'v_dar_analytics_platform',
          controls: [
            'v_dar_analytics_platform',
            'v_dar_bi_data_access_type'
          ],
          valid: () =>
            this.controlHasValue(
              'v_dar_analytics_platform'
            ) ||
            this.controlHasValue(
              'v_dar_bi_data_access_type'
            )
        },
        {
          label: 'Oracle Access',
          control:
            'v_dar_select_an_oracle_access_type'
        },
        {
          label: 'Other Platform',
          control: 'v_dar_OtherType'
        },
        {
          label: 'Personal Information',
          control: 'edm_PI_personal_details'
        },
        {
          label: 'Type of Work',
          control: 'v_edm_type_of_work'
        },
        {
          label: '3rd Party Vendor',
          control: 'v_edm_3rd_party_vendor'
        }
      ];

    return definitions
      .filter(definition =>
        this.requirementExists(definition) &&
        this.requirementIsActive(definition)
      )
      .map(definition => ({
        label: definition.label,
        control: definition.control,

        valid: definition.valid
          ? definition.valid()
          : this.controlIsComplete(
              definition.control
            )
      }));
  }

  get remainingFields():
    RequiredFieldItem[] {
    return this.requiredFields.filter(
      field => !field.valid
    );
  }

  private requirementExists(
    definition: RequiredFieldDefinition
  ): boolean {
    const names =
      definition.controls?.length
        ? definition.controls
        : [definition.control];

    return names.some(name =>
      this.form.contains(name)
    );
  }

  private requirementIsActive(
    definition: RequiredFieldDefinition
  ): boolean {
    if (
      definition.visible &&
      !definition.visible()
    ) {
      return false;
    }

    const names =
      definition.controls?.length
        ? definition.controls
        : [definition.control];

    return names.some(name => {
      const field = this.fieldByKey(name);
      const control = this.form.get(name);

      if (!field || !control) {
        return false;
      }

      return (
        this.visible(field) &&
        this.isRequired(field) &&
        control.enabled
      );
    });
  }

  private requestedForIsValid(): boolean {
    return (
      this.controlValue('requesting_id') === 'Me' ||
      this.hasValue(
        this.controlValue(
          'v_dar_objectid_reqfor'
        )
      )
    );
  }

  private requestedForFocusControl(): string {
    const requestingFor =
      this.controlValue('requesting_id');

    if (
      requestingFor &&
      requestingFor !== 'Me' &&
      this.form.contains(
        'v_dar_objectid_reqfor'
      )
    ) {
      return 'v_dar_objectid_reqfor';
    }

    return 'requesting_id';
  }

  private controlValue(
    controlName: string
  ): unknown {
    return this.form.get(controlName)?.value;
  }

  private hasValue(
    value: unknown
  ): boolean {
    if (
      value === null ||
      value === undefined
    ) {
      return false;
    }

    if (typeof value === 'string') {
      return value.trim().length > 0;
    }

    if (Array.isArray(value)) {
      return value.length > 0;
    }

    if (typeof value === 'boolean') {
      return value;
    }

    return true;
  }

  private controlHasValue(
    controlName: string
  ): boolean {
    const control =
      this.form.get(controlName);

    return (
      !!control &&
      control.enabled &&
      this.hasValue(control.value)
    );
  }

  private controlIsComplete(
    controlName: string
  ): boolean {
    const control =
      this.form.get(controlName);

    return (
      !!control &&
      control.enabled &&
      control.valid
    );
  }

  isValid(
    controlName: string
  ): boolean {
    const control =
      this.form.get(controlName);

    return (
      !!control &&
      control.touched &&
      control.valid
    );
  }

  isInvalid(
    controlName: string
  ): boolean {
    const control =
      this.form.get(controlName);

    return (
      !!control &&
      control.touched &&
      control.invalid
    );
  }

  focusField(
    controlName: string
  ): void {
    let targetControlName =
      controlName;

    let control =
      this.form.get(targetControlName);

    if (
      !control &&
      controlName ===
        'v_dar_analytics_platform'
    ) {
      targetControlName =
        'v_dar_bi_data_access_type';

      control =
        this.form.get(targetControlName);
    }

    if (
      !control ||
      control.disabled
    ) {
      return;
    }

    control.markAsTouched();

    control.updateValueAndValidity({
      emitEvent: false
    });

    const element =
      document.getElementById(
        targetControlName
      );

    if (!element) {
      return;
    }

    element.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });

    window.setTimeout(() => {
      (element as HTMLElement).focus({
        preventScroll: true
      });
    }, 250);
  }

  handleRequiredFieldKeydown(event: KeyboardEvent, controlName: string): void {
    if (event.key !== 'Enter' && event.key !== ' ') {
      return;
    }

    event.preventDefault();

    this.focusField(controlName);
  }

  control(field: DarField): AbstractControl | null {
    return this.form.get(field.key);
  }

  inputType(field: DarField): string {
    switch (field.field_type) {
      case 'integer':
      case 'decimal': return 'number';
      case 'datetime': return 'datetime-local';
      case 'date': return 'date';
      case 'email': return 'email';
      default: return 'text';
    }
  }

  isTermsField(field: DarField): boolean {
    return (field.key === 'chk_dar_terms_message');
  }

  helpId(field: DarField): string {
    return `${field.key}-help`;
  }

  errorId(field: DarField): string {
    return `${field.key}-error`;
  }

  describedBy(field: DarField): string | null {
    const ids: string[] = [];

    if (field.help_text) {
      ids.push(this.helpId(field));
    }

    if (this.error(field)) {
      ids.push(this.errorId(field));
    }

    return ids.length ? ids.join(' ') : null;
  }

  error(
    field: DarField
  ): string {
    const serverError = this.serverErrors[field.key];
    if (serverError) {return Array.isArray(serverError) ? serverError[0] : serverError;}
    const control = this.form.get(field.key);

    if (!control || control.disabled || !control.touched || !control.errors) {
      return '';
    }

    if (control.errors['required'] || control.errors['requiredTrue']) {
      return (field.error_message || 'This field is required.');
    }

    if (control.errors['email']) {
      return 'Enter a valid email address.';
    }

    if (control.errors['minlength']) {
      return (`Enter at least ${control.errors['minlength'].requiredLength
        } characters.`
      );
    }

    if (control.errors['maxlength']) {
      return (`Enter no more than ${
          control.errors['maxlength'].requiredLength
        } characters.`
      );
    }

    if (control.errors['pattern']) {
      return (field.error_message || 'The format is invalid.');
    }

    return (field.error_message || 'Invalid value.');
  }

  onSubmit(): void {
    if (this.submitting) {
      return;
    }

    this.success = undefined;
    this.fatal = undefined;
    this.serverErrors = {};
    this.updateConditionalControls();
    this.form.markAllAsTouched();

    this.form.updateValueAndValidity({
      emitEvent: false
    });

    if (this.form.invalid || this.remainingFields.length > 0) {
      this.focusFirstInvalidField();
      return;
    }

    this.submitting = true;
    const payload = this.activeSubmissionData();

    this.api.submit(this.formSlug, payload).pipe(takeUntil(this.destroy$)).subscribe({next: response => {
          this.success = this.schema?.success_message || this.schema?.success_title || `Request ${response.id} submitted.`;
          this.submitting = false;
        },

        error: errorResponse => {
          const responseData = errorResponse?.error?.data;
          this.serverErrors = responseData && typeof responseData === 'object' ? responseData : {};
          this.fatal = errorResponse?.error?.routing || errorResponse?.error ?.configuration || errorResponse?.error?.detail || 'The request could not be submitted.';
          this.submitting = false;

          window.setTimeout(() =>
            this.focusFirstInvalidField()
          );
        }
      });
  }

  /*
   * Submit only active controls.
   *
   * Do not use getRawValue() here because it restores disabled controls
   * to the payload. Django rejects or excludes fields based on resolved
   * hidden/disabled state.
   */
  private activeSubmissionData():
    Record<string, unknown> {
    const data: Record<string, unknown> = {};

    for (const field of this.fields()) {
      if (field.field_type === 'static_text' || field.field_type === 'hidden' || field.read_only) {
        continue;
      }

      const state = this.runtimeState[field.key];
      const control = this.form.get(field.key);

      if (!state || !control || state.hidden || state.disabled || state.readOnly || control.disabled) {
        continue;
      }
      data[field.key] = control.value;
    }

    return data;
  }

  private focusFirstInvalidField(): void {
    const firstRequirement =
      this.remainingFields[0];

    if (firstRequirement) {
      this.focusField(
        firstRequirement.control
      );

      return;
    }

    const invalidControlName =
      Object.keys(this.form.controls)
        .find(controlName => {
          const control =
            this.form.get(controlName);

          return (
            !!control &&
            control.enabled &&
            control.invalid
          );
        });

    if (invalidControlName) {
      this.focusField(
        invalidControlName
      );
    }
  }

  track(
    _: number,
    field: DarField
  ): number | string {
    return field.id || field.key;
  }

  trackRequiredField(
    _: number,
    field: RequiredFieldItem
  ): string {
    return (
      `${field.label}-${field.control}`
    );
  }
}
