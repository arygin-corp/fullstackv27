resource "aws_ecs_cluster" "this" {name=var.name;setting{name="containerInsights";value="enabled"};tags=merge(var.tags,{"tmna:environment"=var.environment})}
resource "aws_ecs_cluster_capacity_providers" "this" {cluster_name=aws_ecs_cluster.this.name;capacity_providers=["FARGATE","FARGATE_SPOT"];default_capacity_provider_strategy{capacity_provider="FARGATE";weight=1}}
