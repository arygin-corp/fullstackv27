locals {
  environment = "qa"
  admin_host = "admin.qa.data.toyota.com"
  angular_origin = "https://qa.data.toyota.com"
  listener_priority = 3
  frontend_bucket_name = "edmp-gdxp-nonprod-qa-admin"
  certificate_arn = "arn:aws:acm:us-west-2:963334842848:certificate/a5c31abf-0771-4cf2-976c-72fa90a6618f"
  route53_zone_id = "Z07056893PYOYHNHDX3X0"
  application_bucket_name = "edmp-gdxp-nonprod-qa-admin"
  db_name = "edmp_gdxp_admin_qa"
  secret_name = "edmp-gdxp-admin-qa-runtime"
  settings_module = "gdx.settings.qa"
  image_uri = get_env("GDXP_ADMIN_IMAGE_URI", "")
  secret_values = {
    GDX_SECRET_KEY = get_env("GDX_SECRET_KEY", "")
    DB_USER = get_env("DB_USER", "")
    DB_PASSWORD = get_env("DB_PASSWORD", "")
    MICROSOFT_APP_SECRET = get_env("MICROSOFT_APP_SECRET", "")
    PEOPLEFINDER_MICROSOFT_AUTH_CLIENT_SECRET = get_env("PEOPLEFINDER_MICROSOFT_AUTH_CLIENT_SECRET", "")
    TDSP_PODS_USERNAME = get_env("TDSP_PODS_USERNAME", "")
    TDSP_PODS_PASSWORD = get_env("TDSP_PODS_PASSWORD", "")
    MONITORING_TOKEN = get_env("MONITORING_TOKEN", "")
  }
}
