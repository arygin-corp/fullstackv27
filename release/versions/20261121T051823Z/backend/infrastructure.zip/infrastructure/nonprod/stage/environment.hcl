locals {
  environment = "stage"
  admin_host = "admin.stage.data.toyota.com"
  angular_origin = "https://stage.data.toyota.com"
  listener_priority = 4
  frontend_bucket_name = "edmp-gdxp-nonprod-stage-admin"
  certificate_arn = "arn:aws:acm:us-west-2:963334842848:certificate/cee1dbbd-3963-448a-8fc5-4ee24f4ab1c6"
  route53_zone_id = "Z05445923VK2SSXZE0ZDV"
  application_bucket_name = "edmp-gdxp-nonprod-stage-admin"
  db_name = "edmp_gdxp_admin_stage"
  secret_name = "edmp-gdxp-admin-stage-runtime"
  settings_module = "gdx.settings.stage"
  image_uri = get_env("GDXP_ADMIN_IMAGE_URI", "")
  secret_values = {
    GDX_SECRET_KEY = get_env("GDX_SECRET_KEY", "")
    DB_USER = get_env("DB_USER", "")
    DB_PASSWORD = get_env("DB_PASSWORD", "")
    MICROSOFT_APP_SECRET = get_env("MICROSOFT_APP_SECRET", "")
    PEOPLEFINDER_MICROSOFT_AUTH_CLIENT_SECRET = get_env("PEOPLEFINDER_MICROSOFT_AUTH_CLIENT_SECRET", "")
    TDSP_PODS_USERNAME = get_env("TDSP_PODS_USERNAME", "")
    TDSP_PODS_PASSWORD = get_env("TDSP_PODS_PASSWORD", "")
    MONITORING_TOKEN = get_env("MONITORING_TOKEN", "")
  }
}
